# ICEBREAKER — Interactive Hockey Shootout

A self-contained interactive hockey shootout game built with HTML, CSS, JavaScript and SVG.

## Features
- Five-shot challenge with score, accuracy and streak tracking
- Aim and shot-power sliders that change the outcome probabilities
- Animated puck and goalie
- Optional synthesized sound effects
- Responsive layout, no dependencies, no external images

## Play locally
Open `index.html` in any modern browser.

## Publish on GitHub Pages
1. Create a **public** repository named `hockey-shootout`.
2. Upload `index.html` and `README.md` to the repository root and commit.
3. Go to Settings > Pages, select Deploy from a branch, then `main` and `/(root)`.
4. Wait for deployment and open `https://YOUR-USERNAME.github.io/hockey-shootout/`.

This is a fictional arcade-style simulation, not an NHL data model.
